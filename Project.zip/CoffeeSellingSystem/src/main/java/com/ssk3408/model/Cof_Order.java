package com.ssk3408.model;

public class Cof_Order {
	String cofID;
	String orderID;
	int quantity;
	public String getCofID() {
		return cofID;
	}
	public void setCofID(String cofID) {
		this.cofID = cofID;
	}
	public String getOrderID() {
		return orderID;
	}
	public void setOrderID(String orderid) {
		this.orderID = orderid;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
